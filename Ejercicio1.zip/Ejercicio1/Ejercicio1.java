package packpage;
public class Ejercicio1 {

	public static void main(String[] args) {
		
		App app = new App();
System.out.println(app.sayHello());		
		//"AE1-1"
		
	}

}
