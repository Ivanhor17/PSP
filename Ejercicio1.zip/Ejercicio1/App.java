package packpage;

public class App {
//AE1-1
	
	String Hola = "Hola Mundo";
	public String sayHello() {
	return Hola;
	}
}
