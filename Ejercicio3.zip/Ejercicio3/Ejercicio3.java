package packpage;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado = new Scanner(System.in);

String nombre;


 //ArrayList nombres = new Arraylist[6]; 
	for(int i = 1 ; i <= 5 ; i++) {
	System.out.println("Dime el " + i + " nombre ");
	nombre = teclado.next();
	
	}
	}
}
