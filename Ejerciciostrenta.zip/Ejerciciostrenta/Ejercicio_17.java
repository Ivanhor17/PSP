package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio_17 {

	public static void main(String[] args) { 
		String contraseña;
		Scanner teclado = new Scanner(System.in);
        System.out.println("Introduce una contraseña:");
        contraseña = teclado.next();

        boolean tieneNumero = false;
        boolean tieneMayuscula = false;

        
        if (contraseña.length() >= 5) {
                for (int i = 0; i < contraseña.length(); i++) {
                char letra = contraseña.charAt(i);
                if (letra >= '0' && letra <= '9') {
                    tieneNumero = true;
                }
                if (letra >= 'A' && letra <= 'Z') {
                    tieneMayuscula = true;
                }
            }
        }

        if (contraseña.length() >= 5 && tieneNumero && tieneMayuscula) {
            System.out.println("La contraseña es válida");
        } else {
            System.out.println("La contraseña no es valida");
        }
    }
}
	
	

