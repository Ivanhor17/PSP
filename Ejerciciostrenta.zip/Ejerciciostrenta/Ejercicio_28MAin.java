package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio_28MAin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner teclado = new Scanner(System.in);
	        Ejercicio_28[] vehiculos = new Ejercicio_28[5];

	        for (int i = 0; i < vehiculos.length; i++) {
	            System.out.print("Introduce el tipo de vehículo (coche, motocicleta, etc.): ");
	            String tipo = teclado.next();

	            System.out.print("Introduce la marca del vehículo: ");
	            String marca = teclado.next();

	            System.out.print("Introduce el modelo del vehículo: ");
	            String modelo = teclado.next();

	            vehiculos[i] = new Ejercicio_28(tipo, marca, modelo);
	        }

	        System.out.println("\nInformación de los vehículos:");
	        for (Ejercicio_28 vehiculo : vehiculos) {
	            vehiculo.mostrarInfo();
	        }
	}

}
