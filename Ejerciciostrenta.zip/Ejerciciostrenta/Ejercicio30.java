package Ejerciciostrenta;

public class Ejercicio30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("hola mundo");

System.out.println("generando archivos .jar");	
}

}
