package Ejerciciostrenta;

public class Ejercicio_28 {
	  private String tipo;
	    private String marca;
	    private String modelo;

	    // Constructor
	    public Ejercicio_28(String tipo, String marca, String modelo) {
		this.tipo = tipo;
	        this.marca = marca;
	        this.modelo = modelo;	
	
	        
	    }

	    public void mostrarInfo() {
	        System.out.println("Tipo: " + tipo + ", Marca: " + marca + ", Modelo: " + modelo);
	    }
	}

