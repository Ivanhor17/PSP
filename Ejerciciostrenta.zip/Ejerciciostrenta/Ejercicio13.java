package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner teclado = new Scanner(System.in);
	       
	        System.out.print("Ingrese el valor en grados Celsius: ");
	        double celsius = teclado.nextDouble();
	       
	        double fahrenheit = (celsius * 9/5) + 32;
	        
	        System.out.println("El valor en grados Fahrenheit es:" + fahrenheit);
	}

}
