package Ejerciciostrenta;

import java.util.Random;
import java.util.Scanner;

public class Ejercicio_24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    Scanner teclado = new Scanner(System.in);
		int min = 1;
        int max = 10;
        int numero ;
        
   
        System.out.println("Introduce un número entre " + min + " y " + max + ":");
        numero = teclado.nextInt();
        Random random = new Random();
        int numeroAleatorio = random.nextInt(max - min + 1) + min;
        System.out.println("Tu número: " + numero);
        System.out.println("Número aleatorio: " + numeroAleatorio);
        if (numero== numeroAleatorio) {
            System.out.println("Ganaste " );
        } else {

            System.out.println("No coincidieron. has perdido ");
        }
    
        
	}}
