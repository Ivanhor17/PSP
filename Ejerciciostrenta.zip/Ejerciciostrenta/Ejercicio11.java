package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio11 {

	public static void main(String[] args) {
		  Scanner teclado = new Scanner(System.in);
	        System.out.print("Introduce tu número de DNI (sin la letra): ");
	        int dni = teclado.nextInt();
	        Ejercicio_27 ejercicio27 = new Ejercicio_27();
	        char letra = ejercicio27.calcularLetraDNI(dni);

	        System.out.println("La letra correspondiente DNI:" + dni + " es:" + letra);
	        teclado.close();
	    }
	
	}
