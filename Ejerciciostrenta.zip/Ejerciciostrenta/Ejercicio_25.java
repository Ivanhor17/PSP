package Ejerciciostrenta;

import java.util.Random;
import java.util.Scanner;

public class Ejercicio_25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    Scanner teclado = new Scanner(System.in);
		int min = 1;
        int max = 10;
        int numero ;
        double apuesta;
        String opcion;
        int recompensa;
        
        do {
        System.out.println("Introduce el dinero que deseas apostar:");
        apuesta = teclado.nextDouble();
        System.out.println("Introduce un número entre " + min + " y " + max + ":");
        numero = teclado.nextInt();
        Random random = new Random();
        int numeroAleatorio = random.nextInt(max - min + 1) + min;
        System.out.println("Tu número: " + numero);
        System.out.println("Número aleatorio: " + numeroAleatorio);
        if (numero== numeroAleatorio) {
            System.out.println("Ganaste "  + (apuesta * 2) + " €");
            System.out.println("Quieres otro premio ? (si o no)"); 
            opcion = teclado.next();
            switch(opcion) {
            case "si":
            	System.out.println("Pues elige una de estas recompensas: (sorpresa) " + "1 , 2 y 3");
            	recompensa= teclado.nextInt();
            	switch(recompensa) {
            	case 1:
            		System.out.println("Una cena romantica con un/a chica/o elegante");
            		break;
            	case 2:
            		System.out.println("Dos entradas para el barcelona vs Atletico de madrid");
            		break;
            	case 3:
            		System.out.println("Un portatil MSIGamming");
            		break;
            	}
            	break;
            case "no":
            	System.out.println("Felicidades tu premio es tu dinero x2 " + apuesta*2);
            	default:
            		System.out.println("Escribe si o no");
            }
        } else {
        	apuesta = 0;
            System.out.println("No coincidieron. has perdido " + apuesta);
        }}while(apuesta != 0);
    
	
	}}
