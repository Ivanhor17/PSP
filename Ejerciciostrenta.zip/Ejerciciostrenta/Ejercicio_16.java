package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado = new Scanner(System.in);
	int dia;
	int mes;
	int ano;
	int numero_suerte;
	int suma;
System.out.println("Dime tu fecha de nacimiento");
System.out.println("Dime el dia  :");
dia = teclado.nextInt();
System.out.println("Dime el mes (del 1 al 12) :");
mes = teclado.nextInt();
System.out.println("Dime el año :");
ano = teclado.nextInt();
suma = dia + mes + ano;
numero_suerte = sumarDigitos(suma);

System.out.println("Tu número de la suerte es: " + numero_suerte);
}

public static int sumarDigitos(int numero) {
int suma = 0;
while (numero > 0) {
    suma = suma + numero % 10;  
    numero = numero / 10;        
}

if (suma >= 10) {
    return sumarDigitos(suma); 
    } else {
    return suma;
}
}
}
