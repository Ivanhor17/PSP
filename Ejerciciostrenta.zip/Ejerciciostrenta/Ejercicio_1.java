package Ejerciciostrenta;

public class Ejercicio_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int numero = 1;

int numero2 = 2;


System.out.println(numero + numero2 );
	}

}
