package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio_21 {

	public static void main(String[] args) {
		  Scanner teclado = new Scanner(System.in);
	        
	       
	        String[] nombres = new String[5];
	        for (int i = 0; i < 5; i++) {
	            System.out.print("Introduce el nombre de la persona " + (i + 1) + ": ");
	            nombres[i] = teclado.next();
	        }
	        System.out.println("Nombres introducidos:");
	        for (String nombre : nombres) {
	            System.out.println(nombre);
	        }

	}

}
