package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int numero = 0;
		System.out.println("Di un numero del 1 al 12");
		 do  {
	            System.out.println("Dime un número :");
	            numero = teclado.nextInt();  
	        
		 if(numero == 1) {
			System.out.println("Enero"); 
		 } else if(numero == 2) {
			 System.out.println("Febrero");
		 } else if(numero == 3) {
			 System.out.println("Marzo");
		 }else if(numero == 4) {
			 System.out.println("Abril");
		 }else if(numero == 5) {
			 System.out.println("Mayo");
		 }else if(numero == 6) {
			 System.out.println("Junio");
		 }else if(numero == 7) {
			 System.out.println("Julio");
		 }else if(numero == 8) {
			 System.out.println("Agosto");
		 }else if(numero == 9) {
			 System.out.println("Septiembre");
		 }else if(numero == 10) {
			 System.out.println("Octubre");
		 }else if(numero == 11) {
			 System.out.println("Noviembre");
		 }else if(numero == 12) {
			 System.out.println("Diciembre");
		 }
		 }while(numero >= 1 && numero <= 12);
	 
	 System.out.println("El numero que pusiste no esta esta entre el 1 y el 12");
	 }

}
