package Ejerciciostrenta;

public class Ejercicio_27 {

	 public char calcularLetraDNI(int dni) {
	        if (dni < 0 || dni > 99999999) {
	            System.out.println("Error: El DNI debe estar entre 0 y 99999999.");
	            return ' ';
	        }
	        String letras = "TRWAGMYFPDXBNJZSQVHLCKET";
	        int indice = dni % 23;
	        return letras.charAt(indice);
	        }

}
