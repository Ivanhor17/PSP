package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio_5 {

	public static void main(String[] args) {
	Scanner teclado = new Scanner(System.in);
	int numero1;
	int numero2;
	do{
	System.out.println("Dime un numero:");
	numero1 =  teclado.nextInt();
	System.out.println("Dime otro numero:");
	numero2 = teclado.nextInt();	
	}while(numero1 != numero2);
     System.out.println("Los numeros son iguales");
	}

}
