package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner teclado = new Scanner(System.in);
	    
	        System.out.print("Introduce el valor del radio: ");
	        double radio = teclado.nextDouble();
	        double diametro = 2 * radio;
	        double area = 3.14 * radio * radio;
	        double volumen = (4.0 / 3.0) * 3.14 +(radio *radio );
	        System.out.println("Diámetro:"+ diametro);
	        System.out.println("Área:" + area);
	        System.out.println("Volumen de la esfera:"+ volumen);
	        
	}

}
