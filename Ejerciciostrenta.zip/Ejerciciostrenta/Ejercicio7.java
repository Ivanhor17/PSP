package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int numero;
		int suma = 0;
		 for (int i = 1; i <= 5; i++) {
	            System.out.println("Dime el " + i + " número :");
	            numero = teclado.nextInt();
	            suma +=  numero;  
	        }
		 System.out.println("La suma de todos los numeros es: " + suma);
	}

}
