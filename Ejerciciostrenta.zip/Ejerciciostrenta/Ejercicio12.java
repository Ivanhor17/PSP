package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio12 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
        Ejercicio_26 ejercicio26 = new Ejercicio_26(10);

        for (int i = 0; i < 10; i++) {
            System.out.print("Introduce la nota " + (i + 1) + " (0 a 11): ");
            int nota = teclado.nextInt();
            while (nota < 0 || nota > 11) {
                System.out.print("Nota inválida. Introduce una nota entre 0 y 11: ");
                nota = teclado.nextInt();
            }

            ejercicio26.setNota(i, nota);
        }

        ejercicio26.calcularEstadisticas();
        ejercicio26.mostrarEstadisticas();

    }

}
