package Ejerciciostrenta;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner teclado = new Scanner(System.in);
	        ArrayList<Ejercicio_28> vehiculos = new ArrayList<>();

	        String continuar;
	        do {
	            System.out.print("Introduce el tipo de vehículo (coche, motocicleta, etc.): ");
	            String tipo = teclado.next();

	            System.out.print("Introduce la marca del vehículo: ");
	            String marca = teclado.next();

	            System.out.print("Introduce el modelo del vehículo: ");
	            String modelo = teclado.next();

	            vehiculos.add(new Ejercicio_28(tipo, marca, modelo));

	            System.out.print("¿Deseas agregar otro vehículo? (si/no): ");
	            continuar = teclado.next();
	        } while (continuar.equalsIgnoreCase("si"));

	        System.out.println("Información de los vehículos:");
	        for (Ejercicio_28 vehiculo : vehiculos) {
	            vehiculo.mostrarInfo();
	        }
	}

}
