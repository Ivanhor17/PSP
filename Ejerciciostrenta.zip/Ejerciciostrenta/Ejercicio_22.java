package Ejerciciostrenta;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_22 {

	public static void main(String[] args) {
		  
		        Scanner teclado = new Scanner(System.in);
		        ArrayList<String> nombres = new ArrayList<>(); 
		        
		        
		        System.out.println("Introduce los nombres de las personas (introduce '0' para finalizar):");
		        
		        while (true) {
		            System.out.print("Introduce el nombre: ");
		            String nombre = teclado.next();
		            if (nombre.equals("0")) {
		                break; 
		            }
		            
		      
		            nombres.add(nombre);
		        }
		        System.out.println("Nombres introducidos:");
		        for (String nombre : nombres) {
		            System.out.println(nombre); 
		        }
		        

	}

}
