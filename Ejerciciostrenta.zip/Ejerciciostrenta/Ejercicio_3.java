package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado = new Scanner(System.in);

int numero1;
int numero2;
System.out.println("Dime un numero");
numero1 = teclado.nextInt();
System.out.println("Di otro numero");
numero2 = teclado.nextInt();

if (numero1 > numero2) {
	System.out.println("El numero mayor es " + numero1);
}else if (numero1 < numero2){
System.out.println("El numero mayor es " + numero2);
}else if (numero1 == numero2) {
System.out.println("Los numeros son iguales");
}


	}

}
