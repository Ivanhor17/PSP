package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio2 {
public static void main(String[] args) { 
	Scanner teclado = new Scanner(System.in);
	String nombre;
	System.out.println("Cual es tu nombre?");
	nombre = teclado.next();
	System.out.println("hola " + nombre);

	}

}
