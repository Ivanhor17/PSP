package Ejerciciostrenta;

public class Ejercicio_20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  for (int codigo = 0; codigo <= 255; codigo++) {
	            char caracter = (char) codigo;
	            System.out.println("Código: " + codigo + " -> Carácter: " + caracter);
	        }
	    }
	}
