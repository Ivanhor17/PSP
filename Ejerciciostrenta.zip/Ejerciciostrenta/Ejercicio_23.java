package Ejerciciostrenta;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Scanner teclado = new Scanner(System.in);
		  String nombre;
	        ArrayList<String> nombres = new ArrayList<>(); 
	        
	        System.out.println("Introduce los nombres de las personas (introduce '0' para finalizar):");
	        
	        while (true) {
	            System.out.print("Introduce el nombre: ");
	            nombre = teclado.next();
	            

	            if (nombre.equals("0")) {
	                break; }
	            
	          nombres.add(nombre);
	        }
	        System.out.println("\nNombres introducidos:");
	        for (int i = 0; i < nombres.size(); i++) {
	            System.out.println((i + 1) + ". " + nombres.get(i)); 
	        }
	}

}
