package Ejerciciostrenta;

public class Ejercicio_26 {
	  private int[] notas;
	    private int suspensos;
	    private int aprobados;
	    private int notables;
	    private int sobresalientes;
	    private int matriculas;

	    public Ejercicio_26(int cantidad) {
	        notas = new int[cantidad];
	    }

	    public void setNota(int indice, int nota) {
	        notas[indice] = nota;
	    }
	    public String calificar(int nota) {
	        if (nota < 5) {
	            return "Suspenso";
	        } else if (nota < 7) {
	            return "Aprobado";
	        } else if (nota < 9) {
	            return "Notable";
	        } else if (nota < 10) {
	            return "Sobresaliente";
	        } else {
	            return "Matrícula de honor";
	        }
	    }

	    public void calcularEstadisticas() {
	        for (int nota : notas) {
	            String calificacion = calificar(nota);
	            System.out.println("Nota: " + nota + " - Calificación: " + calificacion);

	            switch (calificacion) {
	                case "Suspenso":
	                    suspensos++;
	                    break;
	                case "Aprobado":
	                    aprobados++;
	                    break;
	                case "Notable":
	                    notables++;
	                    break;
	                case "Sobresaliente":
	                    sobresalientes++;
	                    break;
	                case "Matrícula de honor":
	                    matriculas++;
	                    break;
	            }
	        }
	    }

	    public void mostrarEstadisticas() {
	        System.out.println("Resumen de notas:");
	        System.out.println("Suspensos: " + suspensos);
	        System.out.println("Aprobados: " + aprobados);
	        System.out.println("Notables: " + notables);
	        System.out.println("Sobresalientes: " + sobresalientes);
	        System.out.println("Matrícula de honor: " + matriculas);
	    }
	}