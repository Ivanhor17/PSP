package Ejerciciostrenta;

import java.util.Scanner;

public class Ejercicio_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado = new Scanner(System.in);
int numero1;
int numero2;
int numero3;
int numero4;
int numero5;

	System.out.println("Dime un primer numero :");
	numero1 = teclado.nextInt();
	
	System.out.println("Dime un segundo numero :");
	numero2 = teclado.nextInt();
	
	System.out.println("Dime un tercer numero:");
	numero3 = teclado.nextInt();
	
	System.out.println("Dime un cuarto numero:");
	numero4 = teclado.nextInt();
	
	System.out.println("Dime un quinto numero:");
	numero5 = teclado.nextInt();
	
	
	
	
	System.out.println("La suma de los numeros es =" + ( numero1 + numero2 + numero3 + numero4 + numero5));
}

}


