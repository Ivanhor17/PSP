package packpage;

import java.util.Scanner;

public class Ejercicio2_numerosprimos {

	public static void main(String[] args) {
		
		//“AE1-2"
		int numero1;
		int numero2;
		int numerosprimos = 0;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Hola hoy vamos a calcular numeros  primos:");
		
		System.out.println("Dime un numero:");
		numero1 = teclado.nextInt();
		System.out.println("Dime otro numero:");
		numero2 = teclado.nextInt();
		
		if(numero1 >= numero2) {
			for(int i = numero2; i <= numero1; i++){
				
			System.out.println("Los numeros son " + i);	
			}
		}else if(numero2 >= numero1) {
			for(int i = numero1; i <= numero2; i++){
			System.out.println("Los numeros son " + i);
			}}
	System.out.println("La suma de los numeros es: " + (numero1*numero2)+numero2);	
	System.out.println("Los numeros primos son: " + numerosprimos);
	}

}
